
////this function contains all 9 images
///the text and effects appear of the top of each background image 

function screenimage1()

{

  imageMode(CENTER);
   console.log("xx");
  //tint(0);
  ///this defines the size of the background image 
  image(screenimages[screenNo],width/2,height/2,windowWidth,windowHeight);
  
///this is for the transition of images 
	  milliseconds = millis();
	   if(timeover == true)
	   {
	    seconds = milliseconds/1000;
	   }
	   else
	   {
	    seconds = milliseconds/1500;
	   }
  //text(int(seconds),width/2,50);
  ///the speed of the moving tank at the bottom 
  tankx+=0.17;
  image(tank,tankx,tanky,200,300);
  
  
    if(seconds > 1){
    if(screenNo == 0)
   {

        textSize(90);
        textAlign(RIGHT);
        fill(0,102,51,200);
            str="The Syria Story";
        ////this adds effects to the text 
        text(str.slice(0,strsize), width/2,height/2);
            strsize++; 
        //fill(0);
       //ellipse (100,400,80,80);
      //for (var i = 0; i <200; i++) {
     //animation(bullet,200,300);
    //animation(bullet,700,300,200,174);
    
    image(bullet,700,300,200,174);

     if (!soundplayed)
	    {
		  mySound.setVolume(1);
		  mySound.play();
		  soundplayed=true; 
	    }
          effects();
    }
}
    
      if(screenNo == 1) 
    {
      	
      if (!soundplayed)
	{
		  mySound.setVolume(1);
		  mySound.play();
		  soundplayed=true; 
	}


        textSize(25);
        textAlign(CENTER);
        fill(255);
        str="The war in Syria has killed over 220,000 people, uprooted families and left ancient cities like Aleppo in ruins.";
          	text(str.slice(0,strsize),width/2,height/4);
        str1="The descent into war began with the violent and brutal repression of peaceful pro-reform protests."
          	text(str1.slice(0,strsize1) ,width/2,height/3);
        str2="It later turned into an armed uprising against the regime of Bashar al-Assad."
          	text(str2.slice(0,strsize2),width/2,height/2);
        str3="Since then it is a regional conflict involving state and non state actors."
          	text(str3.slice(0,strsize3),width/2,360);
        
	        textSize(35);
	        textAlign(CENTER);
	        fill(0,102,51,200);
        str4="We take a look back at how events unfolded in Syria over the past seven years."
        	text(str4.slice(0,strsize4),width/2,450);
        
////this helps for each line to appear after the the line above it is completed

        strsize++;
          if( strsize>= str.length)
        strsize1++;
          if(strsize1>=str.length)
        strsize2++
          if(strsize2>=str.length)
        strsize3++
          if(strsize3>=str.length)
        strsize4++
        
        fill(187,10,30,10);
        noStroke();  
      //for (var i = 0; i <20; i++)
      for (var j = 0; j <19; j++)
      //console.log("hi"+rain[j].x, rain[j].y);
      rain[j].droplet();

      //rain[j].y+=20;

    }

     if(screenNo == 2) 
        {
           if (!soundplayed)
	{
		  mySound1.setVolume(1);
		  mySound1.play();
		  soundplayed=true; 
	 }

        textSize(45);
        textAlign(CENTER);
        fill(0,102,51,200);
        text('Year 2011',width/2,height/4);
        textSize(25);
        //fill(62,57,69);
       	fill(255);
        str="On 15th March, 100s of people hundreds staged protests in Damascus and Aleppo."
          text(str.slice(0,strsize),width/2,280);
        str1="They demanded democratic reforms,liberty, freedom for political prisoners after 40 years of brutal rule by Assad."
          text(str1.slice(0,strsize1),width/2,320);
        str2= "3 days later security forces opened fire, killing 4 people."
          text(str2.slice(0,strsize2),width/2,360);
        str3="In April, security forces, raided a sit-in."
          text(str3.slice(0,strsize3) , width/2,400);
    
        strsize++;
          if( strsize>= str.length)
        strsize1++;
          if(strsize1>=str.length)
        strsize2++
          if(strsize2>=str.length)
        strsize3++
          if(strsize3>=str.length)
        strsize4++
      
      //for (var i = 0; i <20; i++)
      for (var j = 0; j <19; j++)

      smoke[j].smokyx();
     }

       if(screenNo == 3) 
{

       	if (!soundplayed)
	{
		 mySound2.setVolume(1);
		 mySound2.play();
		 soundplayed=true; 
	}
        textSize(45);
        textAlign(CENTER);
        fill(0,102,51,200);
        text('Year 2012 - All Out War',width/2,height/4);
        textSize(25);
        //fill(62,57,69);
        fill(255);
        str="In July, a bombing at the Syrian national security center in Damascus killed four top officials."
            text(str.slice(0,strsize) ,width/2,280);
	    str1= "By summer the fighting spread to Aleppo and overtime rebels seized control of half of the city."
	        text(str1.slice(0,strsize1),width/2,320);
	    str2="In November, the Syrian National Coalition was created bringing together the mail opposition fations."
	        text(str2.slice(0,strsize2),width/2,360);
	    str3= "The umbrella group was hampered from the outset by infighting."
	       text(str3.slice(0,strsize3), width/2,400);
	    str4="They were also accusations that their members were out-of-touch exiles."
	        text(str4.slice(0,strsize4),width/2,450);
          strsize++;
      if( strsize>= str.length)
        strsize1++;
      if(strsize1>=str.length)
        strsize2++
      if(strsize2>=str.length)
        strsize3++
      if(strsize3>=str.length)
        strsize4++
       redfire();
}


    if(screenNo == 4) 
{
    if (!soundplayed)
	{
		  mySound3.setVolume(0.4);
		  mySound3.play();
		  soundplayed=true; 
	}
        textSize(45);
        textAlign(CENTER);
        fill(0,102,51,200);
        text('Year 2013 - Refugee Crisis',width/2,height/4);
        textSize(25);
        //fill(62,57,69);
        fill(255);
        str="In March, there were over 1 Million refugees, half of them kids."
        	text(str.slice(0,strsize),width/2,280);
        str2="In June, the Syrian army recaptured the key border town of Qusayr, in an assault led by fighters led by Hezbollah."
        	text(str2.slice(0,strsize2),width/2,320);
        str3="In November, the Syrian National Coalition was created bringing together the mail opposition fations."
        	text(str3.slice(0,strsize3),width/2,360);
        str4="The umbrella group was hampered from the outset by infighting."
        	text(str4.slice(0,strsize4), width/2,400);
        str5="They were also accusations that their members were out-of-touch exiles."
        	text(str5.slice(0,strsize5),width/2,450);
          strsize++;
        if( strsize>= str.length)
        	strsize1++;
      	if(strsize1>=str.length)
        	strsize2++
      	if(strsize2>=str.length)
        	strsize3++
        if(strsize3>=str.length)
        	strsize4++
       	if(strsize4>=str.length)
        	strsize5++

		movement();
    }

          	if(screenNo == 5) 
        {

        	if (!soundplayed)
	{
		  mySound4.setVolume(0.4);
		  mySound4.play();
		  soundplayed=true; 
	}

        textSize(45);
        textAlign(CENTER);
        fill(0,102,51,200);
        text('Year 2014 - ISIS',width/2,height/4);
        textSize(25);
        //fill(62,57,69);
       	fill(255);
        str="By Jan 2014, infighting between rebels spread,pitting a variety of groups called ISIS aganist Al-aqeda Breakaway."
        	text(str.slice(0,strsize) ,width/2,280);
        str1="Two rounds of peace talks led by UN-Arab League mediator Lakhdar Brahimi ended without a breakthrough"
        	text(str1.slice(0,strsize1),width/2,320);
        str2="Rebels withdrew from the old quarter of the central city Homs, in a significant victory for the government"
          	text(str2.slice(0,strsize2),width/2,360);
        str3="Syrians in government areas voted in presidential elections. Assad overwhelmingly won with 88.7 percent."
       		text(str3.slice(0,strsize3) , width/2,400);
        str4="IS seized large parts of northern and western Iraq controlling a 3rd of Syria and Iraq."
       		text(str4.slice(0,strsize4)  ,width/2,450);
        strsize++;
        if( strsize>= str.length)
        	strsize1++;
      	if(strsize1>=str.length)
       	 strsize2++
      	if(strsize2>=str.length)
        	strsize3++
        if(strsize3>=str.length)
        	strsize4++
   		for (var j = 0; j <19; j++)
      //console.log("hi"+red[j].x, red[j].y);
      reds[j].reds2();
    }

    if(screenNo == 6) 
    {
        textSize(45);
        textAlign(CENTER);
        fill(0,102,51,200);
        text('Year 2015 - Russian intervention',width/2,height/4);
        textSize(25);
        //fill(62,57,69);
        fill(255);
        str="In Jan UN estimated Syria conflict had killed at least 220,000 people."
			text(str.slice(0,strsize) ,width/2,280);
  		str1="IS released a video buring captured Jordanian pilot Muath al-Kaseasbeh, sparking outrage in Jordan."
       		text(str1.slice(0,strsize1) ,width/2,320);
        str2="IS overran Christian villages in Syrian eastern Hassakeh province, taking at least 220 Assyrian Christians hostage."
         	text(str2.slice(0,strsize2),width/2,360);
       	str3="In Sept, Russians carried out its first air strikes in Syria, saying they targetted the Islamic State group."
       		text(str3.slice(0,strsize3), width/2,400);
        str4="Syrian Army allowed rebels to evacuate remaining area of Homs"
       		text(str4.slice(0,strsize4) ,width/2,450);
        strsize++;
        if( strsize>= str.length)
        	strsize1++;
      	if(strsize1>=str.length)
        	strsize2++
      	if(strsize2>=str.length)
        	strsize3++
        if(strsize3>=str.length)
        	strsize4++
    	orangefire();
    }

    if(screenNo == 7) 
    {

        textSize(45);
        textAlign(CENTER);
        fill(0,102,51,200);
        text('Year 2016',width/2,height/4);
        textSize(25);
        //fill(62,57,69);
       	fill(255);
        str="In March, Syrian government forces retake Palmyra from Islamic State with Russian air assistance."
         	text(str.slice(0,strsize),width/2,280);
        str1="Turkish troops crossed into Syria to help rebel groups push back Islamic State militants and Kurdish-led rebels "
         	text(str1.slice(0,strsize1),width/2,320);
        str2="Government troops, backed by Russian air power and Iranian-sponsored militias, recaptured Aleppo."
         	text(str2.slice(0,strsize2),width/2,360);
        str3="This capture deprived the rebels of their last major urban stronghold."
         	text(str3.slice(0,strsize3), width/2,400);
         strsize++;
        	if( strsize>= str.length)
        		strsize1++;
      		if(strsize1>=str.length)
       			 strsize2++
      		if(strsize2>=str.length)
       			 strsize3++
        	if(strsize3>=str.length)
        		strsize4++
         	redfire();

       }

     if(screenNo == 8) 
     {

        textSize(45);
        textAlign(CENTER);
        fill(0,102,51,200);
        text('Year 2017 - US intervenes',width/2,height/4);
        textSize(25);
        //fill(62,57,69);
       	fill(255);
        str="Russia, Iran and Turkey agreed to enforce a ceasefire between the government and non-Islamist rebels"
         	text(str.slice(0,strsize),width/2,280);
        str1="Trump ordered a attack on an airbase from which Syrian government planes staged chemical weapons attack"
         	text(str1.slice(0,strsize1),width/2,320);
        str2="In May US decided to arm the YPG Kurdish Popular Protection Units."
         	text(str2.slice(0,strsize2),width/2,360);
        str3="These fight alongside the main opposition Syrian Democratic Forces, captured Tabqa dam from Islamic State."
         	text(str3.slice(0,strsize3), width/2,400);
        fill(0,102,51,200);
        textSize(45);
        str4="And it Goes On...."
         	text(str4.slice(0,strsize4),width/2,450);
          strsize++;
        if( strsize>= str.length)
        	strsize1++;
      	if(strsize1>=str.length)
        	strsize2++
      	if(strsize2>=str.length)
        	strsize3++
        if(strsize3>=str.length)
        	strsize4++

			for (var j = 0; j <19; j++)
			reds[j].reds2();

     }     
   }

