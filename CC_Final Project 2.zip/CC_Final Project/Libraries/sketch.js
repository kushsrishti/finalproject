screenimages =[];
//listtexts=[];
rain=[];
var milliseconds =0;
var seconds =0;
var tank;
var tankx = 100;
var tanky = 600;
var score = 0;
var gameover = false;

var bullet=0;
strsize=0;
strsize1=0;
strsize2=0;
strsize3=0;
strsize4=0;
strsize5=0;
screenNo=1;
//var mysound=0;

function setup() 
{
  createCanvas(windowWidth,windowHeight);
   //mySound = loadSound('assets/bullet.mp3');
        for (var j = 0; j <20; j++)
        {
            rain.push(new bloodrain(random(windowWidth), 0))
        }
  
}

setInterval(transition, 10000);
// function keyPressed(){
// 	console.log("hhhh");
 
   
// 	if (keyCode==32 && keyIsPressed){
// 		if(screenNo < 3)
// 			screenNo++;
//    }
// }

function transition(){
  console.log("hhhh");
 
   if(screenNo < 8)
      //screenNo++;
      strsize=0;
      strsize1=0;
      strsize2=0;
      strsize3=0;
      strsize4=0;
      strsize5=0;
   }



function preload() {


  tank = loadImage('assets/tank.gif');
 //street1 = loadImage('assets/gif.gif')
 screenimages[0] = loadImage('assets/Screen1.png');
 screenimages[1] = loadImage('assets/screen2.png');
 screenimages[2] = loadImage('assets/screen3.png');
 screenimages[3] = loadImage('assets/screen4.png');
 screenimages[4] = loadImage('assets/screen5.png');
 screenimages[5] = loadImage('assets/screen6.png');
 screenimages[6] = loadImage('assets/screen7.png');
 screenimages[7] = loadImage('assets/screen8.png');
 screenimages[8] = loadImage('assets/screen9.png');
 //bullet =loadImage('assets/bullet.png');
 bullet = loadAnimation("assets/bullet.png", "assets/bullet2.png");
  
}

function draw() {
  background(255);
  screenimage1();

  //streetimage2();
  

}


function screenimage1()

{

  imageMode(CENTER);

  console.log("xx");
  //tint(0);
  image(screenimages[screenNo],width/2,height/2,windowWidth,windowHeight);
 milliseconds = millis();
  
 if(gameover == true){
    
  }

   else{
    seconds = milliseconds/1500;
  }

  fill(0,0,0);
  textSize(60);
  //text(int(seconds),width/2,50);

  tankx+=0.4;
  
  image(tank,tankx,tanky,200,300);
  
  
    if(seconds > 1){
      if(screenNo == 0){

        textSize(90);
        textAlign(RIGHT);
                fill(64,7,120);
                str="The Syria Story";
        text(str.slice(0,strsize), width/2,height/2);
        strsize++;
        //fill(0);
       //ellipse (100,400,80,80);
     //for (var i = 0; i <200; i++) {
      animation(bullet,200,300);
   //  animation(bullet,700,300,200,174);
      //mySound.setVolume(0.1);
  //mySound.play();
        }
    }
    


      if(screenNo == 1) {
          
        textSize(25);
        textAlign(CENTER);
        fill(255);
        str="The war in Syria has killed over 220,000 people, uprooted families and left ancient cities like Aleppo in ruins.";
        text(str.slice(0,strsize),width/2,height/4);
        str1="The descent into war began with the violent and brutal repression of peaceful pro-reform protests."
       text(str1.slice(0,strsize1) ,width/2,height/3);
        str2="It later turned into an armed uprising against the regime of Bashar al-Assad."
         text(str2.slice(0,strsize2),width/2,height/2);
        str3="Since then it is a regional conflict involving state and non state actors."
        text(str3.slice(0,strsize3),width/2,360);
        textSize(35);
        textAlign(CENTER);
        fill(64,7,120);
        str4="We take a look back at how events unfolded in Syria over the past seven years."
        text(str4.slice(0,strsize4),width/2,450);
        

        strsize++;
        if( strsize>= str.length)
        strsize1++;
      if(strsize1>=str.length)
        strsize2++
      if(strsize2>=str.length)
        strsize3++
        if(strsize3>=str.length)
        strsize4++
      fill(187,10,30);
      noStroke();
      
        
      //for (var i = 0; i <20; i++)
      for (var j = 0; j <19; j++)
      //console.log("hi"+rain[j].x, rain[j].y);
      rain[j].droplet();

      rain[j].y+=20;

       }

        if(screenNo == 2) {

        textSize(45);
        textAlign(CENTER);
        fill(64,7,120);
        text('Year 2011',width/2,height/4);
        textSize(25);
        //fill(62,57,69);
       fill(255);

        str="On 15th March, 100s of people hundreds staged protests in Damascus and Aleppo."
         text(str.slice(0,strsize),width/2,280);
   
        str1="They demanded democratic reforms,liberty, freedom for political prisoners after 40 years of brutal rule by Assad."
          text(str1.slice(0,strsize1),width/2,320);
        str2= "3 days later security forces opened fire, killing 4 people, the first people to be killed in the uprising."
        text(str2.slice(0,strsize2),width/2,360);
        str3="In April, security forces, raided a sit-in in the third largest Syrian city."
       text(str3.slice(0,strsize3) , width/2,400);
        str4="In August, President Obama called on Assad to reisgn and ordered Syrian Government Assets to be frozen."
       text(str4.slice(0,strsize4) ,width/2,450);
          strsize++;
        if( strsize>= str.length)
        strsize1++;
      if(strsize1>=str.length)
        strsize2++
      if(strsize2>=str.length)
        strsize3++
        if(strsize3>=str.length)
        strsize4++

       }

       if(screenNo == 3) {

        textSize(45);
        textAlign(CENTER);
        fill(64,7,120);
        text('Year 2012 - All Out War',width/2,height/4);
        textSize(25);
        //fill(62,57,69);
       fill(255);
        str="In July, a bombing at the Syrian national security center in Damascus killed four top officials."
        text(str.slice(0,strsize) ,width/2,280);
   
        str1= "By summer the fighting spread to Aleppo and overtime rebels seized control of half of the city."
         text(str1.slice(0,strsize1),width/2,320);
        str2="In November, the Syrian National Coalition was created bringing together the mail opposition fations."
         text(str2.slice(0,strsize2),width/2,360);
        str3= "The umbrella group was hampered from the outset by infighting."
        text(str3.slice(0,strsize3), width/2,400);
        str4="They were also accusations that their members were out-of-touch exiles."
         text(str4.slice(0,strsize4),width/2,450);
          strsize++;
        if( strsize>= str.length)
        strsize1++;
      if(strsize1>=str.length)
        strsize2++
      if(strsize2>=str.length)
        strsize3++
        if(strsize3>=str.length)
        strsize4++

       }


       if(screenNo == 4) {

        textSize(45);
        textAlign(CENTER);
        fill(64,7,120);
        text('Year 2013 - Refugee Crisis',width/2,height/4);
        textSize(25);
        //fill(62,57,69);
       fill(255);
        str="In March, there were over 1 Million refugees, half of them kids."
           text(str.slice(0,strsize),width/2,280);
   
        str2="In June, the Syrian army recaptured the key border town of Qusayr, in an assault led by fighters led by Hezbollah."
        text(str2.slice(0,strsize2),width/2,320);
        str3="In November, the Syrian National Coalition was created bringing together the mail opposition fations."
        text(str3.slice(0,strsize3),width/2,360);
        str4="The umbrella group was hampered from the outset by infighting."
        text(str4.slice(0,strsize4), width/2,400);
        str5="They were also accusations that their members were out-of-touch exiles."
        text(str5.slice(0,strsize5),width/2,450);
          strsize++;
        if( strsize>= str.length)
        strsize1++;
      if(strsize1>=str.length)
        strsize2++
      if(strsize2>=str.length)
        strsize3++
        if(strsize3>=str.length)
        strsize4++
       if(strsize4>=str.length)
        strsize5++


       }

        if(screenNo == 5) {

        textSize(45);
        textAlign(CENTER);
        fill(64,7,120);
        text('Year 2014 - ISIS',width/2,height/4);
        textSize(25);
        //fill(62,57,69);
       fill(255);
        str="By Jan 2014, infighting between rebels spread,pitting a variety of groups called ISIS aganist Al-aqeda Breakaway."
        text(str.slice(0,strsize) ,width/2,280);
   
        str1="Two rounds of peace talks led by UN-Arab League mediator Lakhdar Brahimi ended without a breakthrough"
        text(str1.slice(0,strsize1),width/2,320);
        str2="Rebels withdrew from the old quarter of the central city Homs, in a significant victory for the government"
          text(str2.slice(0,strsize2),width/2,360);
        str3="Syrians in government areas voted in presidential elections. Assad overwhelmingly won with 88.7 percent."
       text(str3.slice(0,strsize3) , width/2,400);
        str4="IS seized large parts of northern and western Iraq controlling a 3rd of Syria and Iraq."
        text(str4.slice(0,strsize4)  ,width/2,450);
          strsize++;
        if( strsize>= str.length)
        strsize1++;
      if(strsize1>=str.length)
        strsize2++
      if(strsize2>=str.length)
        strsize3++
        if(strsize3>=str.length)
        strsize4++

       }

           if(screenNo == 6) {

        textSize(45);
        textAlign(CENTER);
        fill(64,7,120);
        text('Year 2015 - Russian intervention',width/2,height/4);
        textSize(25);
        //fill(62,57,69);
       fill(255);
        str="In Jan UN estimated Syria conflict had killed at least 220,000 people."

       text(str.slice(0,strsize) ,width/2,280);
   
        str1="IS released a video buring captured Jordanian pilot Muath al-Kaseasbeh, sparking outrage in Jordan."
       text(str1.slice(0,strsize1) ,width/2,320);
        str2="IS overran Christian villages in Syrian eastern Hassakeh province, taking at least 220 Assyrian Christians hostage."
         text(str2.slice(0,strsize2),width/2,360);
       str3="In Sept, Russians carried out its first air strikes in Syria, saying they targetted the Islamic State group."
       text(str3.slice(0,strsize3), width/2,400);
        str4="Syrian Army allowed rebels to evacuate remaining area of Homs"
       text(str4.slice(0,strsize4) ,width/2,450);
          strsize++;
        if( strsize>= str.length)
        strsize1++;
      if(strsize1>=str.length)
        strsize2++
      if(strsize2>=str.length)
        strsize3++
        if(strsize3>=str.length)
        strsize4++

       }

          if(screenNo == 7) {

        textSize(45);
        textAlign(CENTER);
        fill(64,7,120);
        text('Year 2016',width/2,height/4);
        textSize(25);
        //fill(62,57,69);
       fill(255);
        str="In March, Syrian government forces retake Palmyra from Islamic State with Russian air assistance."
         text(str.slice(0,strsize),width/2,280);
        str1="Turkish troops crossed into Syria to help rebel groups push back Islamic State militants and Kurdish-led rebels "
         text(str1.slice(0,strsize1),width/2,320);
        str2="Government troops, backed by Russian air power and Iranian-sponsored militias, recaptured Aleppo."
         text(str2.slice(0,strsize2),width/2,360);
        str3="This capture deprived the rebels of their last major urban stronghold."
         text(str3.slice(0,strsize3), width/2,400);
          strsize++;
        if( strsize>= str.length)
        strsize1++;
      if(strsize1>=str.length)
        strsize2++
      if(strsize2>=str.length)
        strsize3++
        if(strsize3>=str.length)
        strsize4++


       }

           if(screenNo == 8) {

        textSize(45);
        textAlign(CENTER);
        fill(64,7,120);
        text('Year 2017 - US intervenes',width/2,height/4);
        textSize(25);
        //fill(62,57,69);
       fill(255);
        str="Russia, Iran and Turkey agreed to enforce a ceasefire between the government and non-Islamist rebels"
         text(str.slice(0,strsize),width/2,280);
   
        str1="Trump ordered a attack on an airbase from which Syrian government planes staged chemical weapons attack"
         text(str1.slice(0,strsize1),width/2,320);
        str2="In May US decided to arm the YPG Kurdish Popular Protection Units."
         text(str2.slice(0,strsize2),width/2,360);
        str3="These fight alongside the main opposition Syrian Democratic Forces, captured Tabqa dam from Islamic State."
         text(str3.slice(0,strsize3), width/2,400);
        str4="US shot down Syrian jet near Raqqa after it dropped bombs near US-backed rebel Syrian Democratic Forces"
         text(str4.slice(0,strsize4),width/2,450);
          strsize++;
        if( strsize>= str.length)
        strsize1++;
      if(strsize1>=str.length)
        strsize2++
      if(strsize2>=str.length)
        strsize3++
        if(strsize3>=str.length)
        strsize4++

       }
}

class bloodrain

{
  constructor(x,y)

  {
    this.x=x;
    this.y=y;
    this.radius=20;
  }

  droplet()

  {
    fill(187,10,30);
    ellipse(this.x,this.y, this.radius, this.radius);
  }

}

